export const getId = (option: any) => {
    const id = option.id || option.value;
    return id;
};
